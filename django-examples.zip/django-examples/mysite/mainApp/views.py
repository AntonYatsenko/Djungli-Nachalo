from django.shortcuts import render

def index(request):
    return render(request, 'mainApp/homePage.html')

def contact(request):
    return render(request, 'mainApp/basic.html', {'values':
    ['Если у Вас остались вопросы - обращаться по телефону или мылу',
    '8(916)-041-28-86','yacentoxasteam@mail.ru']})

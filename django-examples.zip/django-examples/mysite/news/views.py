from django.shortcuts import render
#from django.core.paginator import Paginator

#def listing(request):
#    Articles_list = Articles.objects.all()
#    paginator = Paginator(Articles_list, 1)
#
#    page = request.GET.get('page')
#    Articles = paginator.get_page(page)
#    return render(request, 'posts.html', {'Articles': Articles})
#<div class="pagination">
#<span class="step-links">
#    {% if posts.has_previous %}
#        <a href="?page=1">&laquo; first</a>
#        <a href="?page={{ posts.previous_page_number }}">previous</a>
#    {% endif %}
#
#    <span class="current">
#        Page {{ posts.number }} of {{ posts.paginator.num_pages }}.
#    </span>
#
#    {% if posts.has_next %}
#        <a href="?page={{ posts.next_page_number }}">next</a>
#        <a href="?page={{ posts.paginator.num_pages }}">last &raquo;</a>
#    {% endif %}
#</span>
#</div>
